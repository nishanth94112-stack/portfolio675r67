import { db } from "./index";
import {
  profile,
  skills,
  projects,
  achievements,
  contactMessages,
} from "./schema";
import { asc, desc, count } from "drizzle-orm";

let seedingPromise: Promise<void> | null = null;

export async function ensureSeeded() {
  if (seedingPromise) {
    return seedingPromise;
  }

  seedingPromise = (async () => {
    try {
      const [{ value: profileCount }] = await db
        .select({ value: count() })
        .from(profile);

      if (profileCount === 0) {
        await db.insert(profile).values({
          fullName: "Rohith",
          eyebrow: "PORTFOLIO · 2026",
          headline: "Full-Stack Developer / UI Architect / Creator",
          identityRuleLabel: "ROHITH PORTFOLIO",
          homeTitle: "Welcome",
          homeSubtitle:
            "Explore Rohith's background, technical skills, projects, and achievements.",
          homeHighlightTitle:
            "Crafting resilient web applications and refined digital experiences",
          homeHighlightDescription:
            "Navigate through my profile, engineering stack, shipped software projects, and recognitions.",
          aboutTitle: "About me",
          aboutSubtitle: "Background, engineering mindset, and core focus.",
          aboutLabel: "THE DEVELOPER",
          aboutGreeting: "Hey, I’m Rohith.",
          aboutRoleLine: "Full-Stack Developer · UI Architect · Problem Solver",
          aboutIntroLead: "Designing and engineering ",
          aboutIntroAccent:
            "scalable systems, clear interfaces, and purposeful software.",
          aboutCopy:
            "I build end-to-end web platforms with strong architectural discipline—bridging responsive frontend craft with dependable PostgreSQL and TypeScript backends.",
          focusAreas: [
            "Full-stack web systems",
            "Frontend architecture",
            "API & database design",
            "Interactive UI engineering",
          ],
          avatarUrl: "/images/rohith-avatar.png",
          location: "Bengaluru, India",
          availability: "Available for software engineering & product collaborations",
        });
      }

      const [{ value: skillCount }] = await db
        .select({ value: count() })
        .from(skills);

      if (skillCount === 0) {
        await db.insert(skills).values([
          {
            category: "Frontend & Interface",
            name: "React & Next.js",
            description: "App Router, Server Components, SSR, and stateful UI architecture",
            proficiency: "Expert",
            sortOrder: 1,
          },
          {
            category: "Frontend & Interface",
            name: "TypeScript & Modern CSS",
            description: "Strict type safety, responsive systems, and motion choreography",
            proficiency: "Expert",
            sortOrder: 2,
          },
          {
            category: "Backend & Databases",
            name: "Node.js & REST APIs",
            description: "Modular route handlers, validation, authentication, and integrations",
            proficiency: "Advanced",
            sortOrder: 3,
          },
          {
            category: "Backend & Databases",
            name: "PostgreSQL & Drizzle ORM",
            description: "Relational schema modeling, migrations, indexing, and query optimization",
            proficiency: "Advanced",
            sortOrder: 4,
          },
          {
            category: "Engineering & Tooling",
            name: "System Design & Git Workflows",
            description: "Clean code architecture, automated testing, and CI/CD pipelines",
            proficiency: "Advanced",
            sortOrder: 5,
          },
          {
            category: "Engineering & Tooling",
            name: "UI Prototyping & Accessibility",
            description: "WCAG keyboard navigation, semantic HTML, and design systems",
            proficiency: "Proficient",
            sortOrder: 6,
          },
        ]);
      }

      const [{ value: projectCount }] = await db
        .select({ value: count() })
        .from(projects);

      if (projectCount === 0) {
        await db.insert(projects).values([
          {
            title: "AetherGrid Analytics",
            summary:
              "Real-time telemetry and operational intelligence dashboard built with Next.js and PostgreSQL.",
            details:
              "Designed and engineered a multi-tenant metrics platform featuring sub-second query aggregation, role-based workspace controls, and responsive interactive charts.",
            techStack: ["Next.js", "TypeScript", "PostgreSQL", "Drizzle ORM"],
            category: "Full-Stack Platform",
            year: "2026",
            featured: true,
            thumbnailUrl: "/images/project-featured.png",
            liveUrl: "#projects",
            repoUrl: "#contact",
            sortOrder: 1,
          },
          {
            title: "PulseDesk Issue Tracker",
            summary:
              "Keyboard-first sprint planning and engineering workflow tool with instant state sync.",
            details:
              "Built a streamlined project coordination app supporting custom triage queues, optimistic updates, and structured audit trails backed by PostgreSQL.",
            techStack: ["React", "Node.js", "PostgreSQL", "Tailwind CSS"],
            category: "Productivity Web App",
            year: "2025",
            featured: false,
            thumbnailUrl: "",
            liveUrl: "#projects",
            repoUrl: "#contact",
            sortOrder: 2,
          },
          {
            title: "VergeCommerce Engine",
            summary:
              "Headless storefront and inventory API supporting high-throughput catalog filtering.",
            details:
              "Implemented normalized product variants, transactional order processing, and clean REST endpoints for web and mobile clients.",
            techStack: ["TypeScript", "Next.js", "PostgreSQL", "REST API"],
            category: "Backend & Storefront",
            year: "2025",
            featured: false,
            thumbnailUrl: "",
            liveUrl: "#projects",
            repoUrl: "#contact",
            sortOrder: 3,
          },
          {
            title: "AtlasDocs Knowledge Portal",
            summary:
              "Structured technical documentation hub with instant full-text search and versioned guides.",
            details:
              "Created an editorial-grade documentation engine with fast indexed search, clean typography, and interactive API playgrounds.",
            techStack: ["Next.js", "TypeScript", "PostgreSQL"],
            category: "Developer Tooling",
            year: "2024",
            featured: false,
            thumbnailUrl: "",
            liveUrl: "#projects",
            repoUrl: "#contact",
            sortOrder: 4,
          },
        ]);
      }

      const [{ value: achievementCount }] = await db
        .select({ value: count() })
        .from(achievements);

      if (achievementCount === 0) {
        await db.insert(achievements).values([
          {
            title: "National Cloud & Web Engineering Hackathon Winner",
            issuer: "TechSummit India",
            year: "2025",
            category: "Recognition",
            description:
              "Awarded top honors among 180+ engineering teams for building a resilient real-time logistics platform in 36 hours.",
            sortOrder: 1,
          },
          {
            title: "AWS Certified Solutions Architect – Associate",
            issuer: "Amazon Web Services",
            year: "2025",
            category: "Certification",
            description:
              "Validated expertise in designing fault-tolerant, scalable, and cost-efficient distributed cloud architectures.",
            sortOrder: 2,
          },
          {
            title: "Open Source Core Contributor Recognition",
            issuer: "Developer Ecosystem Guild",
            year: "2024",
            category: "Open Source",
            description:
              "Recognized for shipping performance improvements and TypeScript type definitions across widely adopted web utilities.",
            sortOrder: 3,
          },
          {
            title: "Dean’s Merit List in Computer Science & Engineering",
            issuer: "Department of Computer Science",
            year: "2024",
            category: "Academic Honor",
            description:
              "Graduated in the top 5% with distinction in database systems, algorithms, and software architecture.",
            sortOrder: 4,
          },
        ]);
      }
    } finally {
      seedingPromise = null;
    }
  })();

  return seedingPromise;
}

export async function getPortfolioData() {
  await ensureSeeded();

  const [profileRows, skillRows, projectRows, achievementRows, messageRows] =
    await Promise.all([
      db.select().from(profile).limit(1),
      db
        .select()
        .from(skills)
        .orderBy(asc(skills.sortOrder), asc(skills.id)),
      db
        .select()
        .from(projects)
        .orderBy(desc(projects.featured), asc(projects.sortOrder), asc(projects.id)),
      db
        .select()
        .from(achievements)
        .orderBy(asc(achievements.sortOrder), asc(achievements.id)),
      db
        .select()
        .from(contactMessages)
        .orderBy(desc(contactMessages.createdAt), desc(contactMessages.id))
        .limit(20),
    ]);

  return {
    profile: profileRows[0] ?? null,
    skills: skillRows,
    projects: projectRows,
    achievements: achievementRows,
    messages: messageRows,
  };
}
