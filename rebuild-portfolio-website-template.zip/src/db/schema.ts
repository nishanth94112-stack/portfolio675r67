import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
} from "drizzle-orm/pg-core";

export const profile = pgTable("profile", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  eyebrow: text("eyebrow").notNull(),
  headline: text("headline").notNull(),
  identityRuleLabel: text("identity_rule_label").notNull(),
  homeTitle: text("home_title").notNull(),
  homeSubtitle: text("home_subtitle").notNull(),
  homeHighlightTitle: text("home_highlight_title").notNull(),
  homeHighlightDescription: text("home_highlight_description").notNull(),
  aboutTitle: text("about_title").notNull(),
  aboutSubtitle: text("about_subtitle").notNull(),
  aboutLabel: text("about_label").notNull(),
  aboutGreeting: text("about_greeting").notNull(),
  aboutRoleLine: text("about_role_line").notNull(),
  aboutIntroLead: text("about_intro_lead").notNull(),
  aboutIntroAccent: text("about_intro_accent").notNull(),
  aboutCopy: text("about_copy").notNull(),
  focusAreas: jsonb("focus_areas").$type<string[]>().notNull(),
  avatarUrl: text("avatar_url").notNull(),
  location: text("location").notNull(),
  availability: text("availability").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  proficiency: text("proficiency").notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  details: text("details").notNull(),
  techStack: jsonb("tech_stack").$type<string[]>().notNull(),
  category: text("category").notNull(),
  year: text("year").notNull(),
  featured: boolean("featured").default(false).notNull(),
  thumbnailUrl: text("thumbnail_url").default("").notNull(),
  liveUrl: text("live_url").default("").notNull(),
  repoUrl: text("repo_url").default("").notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  issuer: text("issuer").notNull(),
  year: text("year").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  senderName: text("sender_name").notNull(),
  senderEmail: text("sender_email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  status: text("status").default("new").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type ProfileRecord = typeof profile.$inferSelect;
export type SkillRecord = typeof skills.$inferSelect;
export type ProjectRecord = typeof projects.$inferSelect;
export type AchievementRecord = typeof achievements.$inferSelect;
export type ContactMessageRecord = typeof contactMessages.$inferSelect;
