"use client";

import React, { useEffect, useRef, useState, useCallback } from "react";
import {
  motion,
  AnimatePresence,
  MotionConfig,
  useMotionValue,
  useTransform,
  animate,
  useReducedMotion,
  type MotionValue,
} from "framer-motion";
import {
  Home,
  User,
  Cpu,
  FolderGit2,
  Award,
  Mail,
  ArrowUpRight,
  ChevronLeft,
  ChevronRight,
  Volume2,
  VolumeX,
  Share2,
  Pause,
  MoveHorizontal,
  Check,
  Sparkles,
  Layers,
  MapPin,
  SlidersHorizontal,
  X,
  Plus,
  Trash2,
  Send,
  ExternalLink,
} from "lucide-react";
import type {
  ProfileRecord,
  SkillRecord,
  ProjectRecord,
  AchievementRecord,
  ContactMessageRecord,
} from "@/db/schema";

export interface PortfolioPayload {
  profile: ProfileRecord | null;
  skills: SkillRecord[];
  projects: ProjectRecord[];
  achievements: AchievementRecord[];
  messages: ContactMessageRecord[];
}

interface SectionConfig {
  id: "home" | "about" | "skills" | "projects" | "achievements" | "contact";
  label: string;
  icon: React.ComponentType<{
    size?: number;
    strokeWidth?: number;
    "aria-hidden"?: boolean;
  }>;
  title: string;
  subtitle: string;
}

const SPRING_TRANSITION = {
  type: "spring" as const,
  stiffness: 300,
  damping: 28,
};

const SECTIONS: SectionConfig[] = [
  {
    id: "home",
    label: "Home",
    icon: Home,
    title: "Welcome",
    subtitle:
      "Explore Rohith's background, technical skills, projects, and achievements.",
  },
  {
    id: "about",
    label: "About me",
    icon: User,
    title: "About me",
    subtitle: "Background, engineering mindset, and core focus.",
  },
  {
    id: "skills",
    label: "Skills",
    icon: Cpu,
    title: "Skills",
    subtitle: "Core capabilities, technologies, and tools I work with.",
  },
  {
    id: "projects",
    label: "Projects",
    icon: FolderGit2,
    title: "Projects",
    subtitle: "Applications, systems, and web platforms built by Rohith.",
  },
  {
    id: "achievements",
    label: "Achievements",
    icon: Award,
    title: "Achievements",
    subtitle: "Recognitions, certifications, and key career milestones.",
  },
  {
    id: "contact",
    label: "Contact",
    icon: Mail,
    title: "Contact",
    subtitle: "Have an opportunity or idea? Send a message directly.",
  },
];

function wrapDelta(diff: number, total = SECTIONS.length): number {
  const half = total / 2;
  return (((diff + half) % total) + total) % total - half;
}

interface OrbitItemProps {
  section: SectionConfig;
  index: number;
  active: number;
  position: MotionValue<number>;
  geometry: { width: number; height: number; desktop: boolean };
  onSelect: (idx: number) => void;
  buttonRef: (el: HTMLButtonElement | null) => void;
}

function OrbitItem({
  section,
  index,
  active,
  position,
  geometry,
  onSelect,
  buttonRef,
}: OrbitItemProps) {
  const delta = useTransform(position, (pos) => wrapDelta(index - pos));

  const x = useTransform(delta, (d) => {
    const angle = (d * (geometry.desktop ? 19.5 : 22) * Math.PI) / 180;
    return geometry.desktop
      ? geometry.width * 0.5 * (1 + Math.cos(angle))
      : geometry.width * (0.5 + 0.54 * Math.sin(angle));
  });

  const y = useTransform(delta, (d) => {
    const angle = (d * (geometry.desktop ? 19.5 : 22) * Math.PI) / 180;
    return geometry.desktop
      ? geometry.height * 0.5 * (1 + Math.sin(angle))
      : -26 + 75 * Math.cos(angle);
  });

  const opacity = useTransform(delta, (d) =>
    Math.max(0, Math.min(1, (2.75 - Math.abs(d)) / 0.35))
  );

  const Icon = section.icon;
  const isActive = active === index;

  return (
    <motion.button
      ref={buttonRef}
      id={`tab-${section.id}`}
      role="tab"
      aria-selected={isActive}
      aria-controls="main-panel"
      tabIndex={isActive ? 0 : -1}
      className={`orbit-item ${isActive ? "is-active" : ""}`}
      style={{ x, y, opacity }}
      onClick={() => onSelect(index)}
      whileTap={{ scale: 0.9 }}
    >
      <span className="orbit-icon">
        <Icon size={25} strokeWidth={1.25} aria-hidden={true} />
        {isActive && (
          <motion.span
            className="selection-ring"
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.25 }}
          />
        )}
      </span>
      <span className="orbit-label">{section.label}</span>
      <span className="orbit-number">0{index + 1}</span>
    </motion.button>
  );
}

interface OrbitNavProps {
  active: number;
  position: MotionValue<number>;
  geometry: { width: number; height: number; desktop: boolean };
  setGeometry: React.Dispatch<
    React.SetStateAction<{ width: number; height: number; desktop: boolean }>
  >;
  onSelect: (idx: number) => void;
  navRefs: React.MutableRefObject<(HTMLButtonElement | null)[]>;
  onKeyDown: (e: React.KeyboardEvent) => void;
  instant: boolean;
}

function OrbitNav({
  active,
  position,
  geometry,
  setGeometry,
  onSelect,
  navRefs,
  onKeyDown,
  instant,
}: OrbitNavProps) {
  const navRef = useRef<HTMLDivElement | null>(null);
  const dragState = useRef<{
    x: number;
    y: number;
    position: number;
    dragged: boolean;
  } | null>(null);
  const animControls = useRef<ReturnType<typeof animate> | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const snapTo = useCallback(
    (targetIndex: number) => {
      const target = position.get() + wrapDelta(targetIndex - position.get());
      animControls.current?.stop();
      animControls.current = animate(
        position,
        target,
        instant
          ? { duration: 0 }
          : { type: "spring", stiffness: 190, damping: 24, mass: 0.8 }
      );
    },
    [position, instant]
  );

  useEffect(() => {
    const el = navRef.current;
    if (!el) return;
    const observer = new ResizeObserver(() => {
      if (navRef.current) {
        setGeometry({
          width: navRef.current.clientWidth,
          height: navRef.current.clientHeight,
          desktop: window.matchMedia("(min-width:900px)").matches,
        });
      }
    });
    observer.observe(el);
    return () => {
      observer.disconnect();
      animControls.current?.stop();
    };
  }, [setGeometry]);

  useEffect(() => {
    snapTo(active);
  }, [active, snapTo]);

  const finishDrag = (e: React.PointerEvent<HTMLDivElement>) => {
    const state = dragState.current;
    if (!state) return;
    if (state.dragged) {
      const snapped =
        ((Math.round(position.get()) % SECTIONS.length) + SECTIONS.length) %
        SECTIONS.length;
      onSelect(snapped);
      snapTo(snapped);
    }
    setIsDragging(false);
    if (!state.dragged) {
      dragState.current = null;
    }
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
  };

  return (
    <nav aria-label="Primary navigation">
      <div
        ref={navRef}
        className={`orbit-nav is-rotatable ${isDragging ? "is-dragging" : ""}`}
        aria-label="Choose a section; drag to rotate, or use arrow keys"
        role="tablist"
        onKeyDown={onKeyDown}
        onPointerDown={(e) => {
          if (e.button === 0) {
            animControls.current?.stop();
            dragState.current = {
              x: e.clientX,
              y: e.clientY,
              position: position.get(),
              dragged: false,
            };
          }
        }}
        onPointerMove={(e) => {
          const state = dragState.current;
          if (!state || !e.buttons) return;
          const deltaPx = geometry.desktop
            ? e.clientY - state.y
            : e.clientX - state.x;
          if (!state.dragged && Math.abs(deltaPx) < 7) return;
          if (!state.dragged) {
            e.currentTarget.setPointerCapture(e.pointerId);
            state.dragged = true;
            setIsDragging(true);
          }
          position.set(
            state.position - deltaPx / (geometry.desktop ? 112 : 72)
          );
        }}
        onPointerUp={finishDrag}
        onPointerCancel={(e) => {
          if (dragState.current) {
            dragState.current.dragged = true;
          }
          finishDrag(e);
          dragState.current = null;
        }}
        onClickCapture={(e) => {
          if (dragState.current?.dragged) {
            e.preventDefault();
            e.stopPropagation();
            dragState.current = null;
          }
        }}
      >
        {SECTIONS.map((section, index) => (
          <OrbitItem
            key={section.id}
            section={section}
            index={index}
            active={active}
            position={position}
            geometry={geometry}
            onSelect={(idx) => {
              onSelect(idx);
              snapTo(idx);
            }}
            buttonRef={(el) => {
              navRefs.current[index] = el;
            }}
          />
        ))}
      </div>
      <span className="wheel-hint">
        <MoveHorizontal size={10} aria-hidden={true} />
        DRAG TO ROTATE · TAP TO SELECT
      </span>
    </nav>
  );
}

export default function PortfolioShell({
  initialData,
}: {
  initialData: PortfolioPayload;
}) {
  const prefersReducedMotion = useReducedMotion();
  const [data, setData] = useState<PortfolioPayload>(initialData);
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const [direction, setDirection] = useState<number>(1);
  const [motionPaused, setMotionPaused] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string>("");
  const [selectedProject, setSelectedProject] = useState<ProjectRecord | null>(
    null
  );
  const [studioOpen, setStudioOpen] = useState<boolean>(false);
  const [studioTab, setStudioTab] = useState<
    "about" | "skills" | "projects" | "achievements" | "messages"
  >("projects");

  const [geometry, setGeometry] = useState({
    width: 358,
    height: 90,
    desktop: false,
  });

  // Contact form state
  const [senderName, setSenderName] = useState("");
  const [senderEmail, setSenderEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [submittingContact, setSubmittingContact] = useState(false);

  // Studio CRUD form states
  const [aboutForm, setAboutForm] = useState({
    headline: initialData.profile?.headline ?? "",
    aboutGreeting: initialData.profile?.aboutGreeting ?? "",
    aboutRoleLine: initialData.profile?.aboutRoleLine ?? "",
    aboutIntroLead: initialData.profile?.aboutIntroLead ?? "",
    aboutIntroAccent: initialData.profile?.aboutIntroAccent ?? "",
    aboutCopy: initialData.profile?.aboutCopy ?? "",
    location: initialData.profile?.location ?? "",
    availability: initialData.profile?.availability ?? "",
    focusAreas: (initialData.profile?.focusAreas ?? []).join(", "),
  });

  const [skillForm, setSkillForm] = useState({
    name: "",
    category: "Frontend & Interface",
    description: "",
    proficiency: "Advanced",
  });

  const [projectForm, setProjectForm] = useState({
    title: "",
    category: "Full-Stack Platform",
    year: "2026",
    summary: "",
    details: "",
    techStack: "Next.js, TypeScript, PostgreSQL",
    featured: false,
  });

  const [achievementForm, setAchievementForm] = useState({
    title: "",
    issuer: "",
    year: "2026",
    category: "Recognition",
    description: "",
  });

  const [busyAction, setBusyAction] = useState(false);

  const position = useMotionValue(0);
  const ringRotation = useTransform(
    position,
    (pos) => pos * (geometry.desktop ? 19.5 : 22)
  );

  const navRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const touchStart = useRef<{ x: number; y: number } | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const instant = Boolean(prefersReducedMotion) || motionPaused;

  const showToast = useCallback((msg: string) => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToastMessage(msg);
    toastTimer.current = setTimeout(() => setToastMessage(""), 3400);
  }, []);

  const playChime = useCallback(
    (force = false) => {
      if (!soundEnabled && !force) return;
      try {
        const AudioContextClass =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext })
            .webkitAudioContext;
        if (!AudioContextClass) return;
        if (!audioCtxRef.current) {
          audioCtxRef.current = new AudioContextClass();
        }
        const ctx = audioCtxRef.current;
        if (ctx.state === "suspended") {
          ctx.resume();
        }
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(528, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(792, ctx.currentTime + 0.11);
        gain.gain.setValueAtTime(0.035, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.13);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.14);
      } catch {
        // Ignore audio context restrictions
      }
    },
    [soundEnabled]
  );

  const refreshPortfolio = useCallback(async () => {
    try {
      const res = await fetch("/api/portfolio", { cache: "no-store" });
      if (res.ok) {
        const fresh: PortfolioPayload = await res.json();
        setData(fresh);
      }
    } catch {
      // Keep current state on network hiccup
    }
  }, []);

  const selectSection = useCallback(
    (nextIdx: number, focusTab = false) => {
      const normalized =
        ((nextIdx % SECTIONS.length) + SECTIONS.length) % SECTIONS.length;
      if (normalized !== activeIndex) {
        const delta =
          (normalized - activeIndex + SECTIONS.length) % SECTIONS.length;
        setDirection(delta <= SECTIONS.length / 2 ? 1 : -1);
        setActiveIndex(normalized);
        if (typeof window !== "undefined") {
          window.history.replaceState(
            null,
            "",
            `#${SECTIONS[normalized].id}`
          );
        }
        playChime();
      }
      if (focusTab) {
        navRefs.current[normalized]?.focus();
      }
    },
    [activeIndex, playChime]
  );

  useEffect(() => {
    const syncFromHash = () => {
      const hash = window.location.hash.slice(1);
      const found = SECTIONS.findIndex((s) => s.id === hash);
      if (found >= 0) {
        setActiveIndex(found);
        position.set(found);
      }
    };
    syncFromHash();
    window.addEventListener("hashchange", syncFromHash);
    window.addEventListener("popstate", syncFromHash);
    return () => {
      window.removeEventListener("hashchange", syncFromHash);
      window.removeEventListener("popstate", syncFromHash);
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, [position]);

  const handleNavKeyDown = (e: React.KeyboardEvent) => {
    let target: number | undefined;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      target = activeIndex + 1;
    } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      target = activeIndex - 1;
    } else if (e.key === "Home") {
      target = 0;
    } else if (e.key === "End") {
      target = SECTIONS.length - 1;
    }
    if (target !== undefined) {
      e.preventDefault();
      selectSection(target, true);
    }
  };

  const handleShare = async () => {
    playChime();
    const url = `${window.location.origin}${window.location.pathname}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: "Rohith | Portfolio", url });
      } else if (navigator.clipboard) {
        await navigator.clipboard.writeText(url);
        showToast("Portfolio link copied to clipboard.");
      } else {
        showToast("Copy the address bar URL to share Rohith's portfolio.");
      }
    } catch (err: unknown) {
      if ((err as { name?: string })?.name !== "AbortError") {
        showToast("Use your browser menu to share this portfolio.");
      }
    }
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submittingContact) return;
    setSubmittingContact(true);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          senderName,
          senderEmail,
          subject: subject || "Portfolio Inquiry",
          message,
        }),
      });
      const result = await res.json();
      if (!res.ok) {
        showToast(result.error || "Please check your details and try again.");
      } else {
        playChime();
        showToast("Message sent. Rohith will respond soon.");
        setSenderName("");
        setSenderEmail("");
        setSubject("");
        setMessage("");
        await refreshPortfolio();
      }
    } catch {
      showToast("Unable to send message right now.");
    } finally {
      setSubmittingContact(false);
    }
  };

  const handleSaveAbout = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusyAction(true);
    try {
      const res = await fetch("/api/portfolio", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...aboutForm,
          focusAreas: aboutForm.focusAreas
            .split(",")
            .map((s) => s.trim())
            .filter(Boolean),
        }),
      });
      if (res.ok) {
        await refreshPortfolio();
        playChime();
        showToast("Profile & About details saved to PostgreSQL.");
      }
    } finally {
      setBusyAction(false);
    }
  };

  const handleAddSkill = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!skillForm.name.trim() || !skillForm.description.trim()) return;
    setBusyAction(true);
    try {
      const res = await fetch("/api/skills", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(skillForm),
      });
      if (res.ok) {
        setSkillForm({
          name: "",
          category: "Frontend & Interface",
          description: "",
          proficiency: "Advanced",
        });
        await refreshPortfolio();
        playChime();
        showToast("Skill added to database.");
      }
    } finally {
      setBusyAction(false);
    }
  };

  const handleDeleteSkill = async (id: number) => {
    setBusyAction(true);
    try {
      const res = await fetch(`/api/skills?id=${id}`, { method: "DELETE" });
      if (res.ok) {
        await refreshPortfolio();
        showToast("Skill removed.");
      }
    } finally {
      setBusyAction(false);
    }
  };

  const handleAddProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectForm.title.trim() || !projectForm.summary.trim()) return;
    setBusyAction(true);
    try {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(projectForm),
      });
      if (res.ok) {
        setProjectForm({
          title: "",
          category: "Full-Stack Platform",
          year: "2026",
          summary: "",
          details: "",
          techStack: "Next.js, TypeScript, PostgreSQL",
          featured: false,
        });
        await refreshPortfolio();
        playChime();
        showToast("Project saved to PostgreSQL.");
      }
    } finally {
      setBusyAction(false);
    }
  };

  const handleDeleteProject = async (id: number) => {
    setBusyAction(true);
    try {
      const res = await fetch(`/api/projects?id=${id}`, { method: "DELETE" });
      if (res.ok) {
        await refreshPortfolio();
        showToast("Project removed.");
      }
    } finally {
      setBusyAction(false);
    }
  };

  const handleAddAchievement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !achievementForm.title.trim() ||
      !achievementForm.issuer.trim() ||
      !achievementForm.description.trim()
    )
      return;
    setBusyAction(true);
    try {
      const res = await fetch("/api/achievements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(achievementForm),
      });
      if (res.ok) {
        setAchievementForm({
          title: "",
          issuer: "",
          year: "2026",
          category: "Recognition",
          description: "",
        });
        await refreshPortfolio();
        playChime();
        showToast("Achievement saved to PostgreSQL.");
      }
    } finally {
      setBusyAction(false);
    }
  };

  const handleDeleteAchievement = async (id: number) => {
    setBusyAction(true);
    try {
      const res = await fetch(`/api/achievements?id=${id}`, {
        method: "DELETE",
      });
      if (res.ok) {
        await refreshPortfolio();
        showToast("Achievement removed.");
      }
    } finally {
      setBusyAction(false);
    }
  };

  const currentSection = SECTIONS[activeIndex];
  const prof = data.profile;

  // Group skills by category
  const skillsByCategory = data.skills.reduce<Record<string, SkillRecord[]>>(
    (acc, item) => {
      if (!acc[item.category]) acc[item.category] = [];
      acc[item.category].push(item);
      return acc;
    },
    {}
  );

  const featuredProject =
    data.projects.find((p) => p.featured) ?? data.projects[0] ?? null;
  const secondaryProjects = data.projects.filter(
    (p) => p.id !== featuredProject?.id
  );

  const headlineParts = (
    prof?.headline ?? "Full-Stack Developer / UI Architect / Creator"
  ).split("/");

  return (
    <MotionConfig
      reducedMotion={motionPaused ? "always" : "user"}
      transition={motionPaused ? { duration: 0 } : SPRING_TRANSITION}
    >
      <div className="world-backdrop" aria-hidden="true">
        <img
          src="/images/rohith-world.png"
          alt=""
          width={1536}
          height={1024}
          fetchPriority="high"
        />
        <div className="world-shade" />
      </div>

      <div className={`world ${motionPaused ? "motion-paused" : ""}`}>
        <div className="screen-frame" aria-hidden="true">
          <span />
          <span />
          <span />
          <span />
        </div>

        <header className="top-bar">
          <a
            className="wordmark"
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              selectSection(0);
            }}
            aria-label="Rohith, Home"
          >
            <span className="wordmark-symbol">
              r<span>.</span>
            </span>
            <span className="wordmark-text">
              ROHITH
              <span>PORTFOLIO</span>
            </span>
          </a>

          <div className="top-controls">
            <motion.button
              className="utility-button motion-toggle"
              whileTap={{ scale: 0.9 }}
              onClick={() => setMotionPaused((prev) => !prev)}
              aria-label={
                motionPaused
                  ? "Restore full animations"
                  : "Reduce visual effects"
              }
              aria-pressed={motionPaused}
            >
              {motionPaused ? (
                <span className="play-symbol" aria-hidden="true">
                  &#9655;
                </span>
              ) : (
                <Pause size={16} aria-hidden={true} />
              )}
            </motion.button>

            <motion.button
              className="utility-button sound-toggle"
              whileTap={{ scale: 0.9 }}
              onClick={() => {
                if (!soundEnabled) playChime(true);
                setSoundEnabled((prev) => !prev);
              }}
              aria-pressed={soundEnabled}
              aria-label={
                soundEnabled ? "Turn menu sound off" : "Turn menu sound on"
              }
            >
              {soundEnabled ? (
                <Volume2 size={17} aria-hidden={true} />
              ) : (
                <VolumeX size={17} aria-hidden={true} />
              )}
              <span>SOUND {soundEnabled ? "ON" : "OFF"}</span>
            </motion.button>

            <motion.button
              className="utility-button sound-toggle"
              whileTap={{ scale: 0.9 }}
              onClick={() => setStudioOpen(true)}
              aria-label="Manage portfolio content"
            >
              <SlidersHorizontal size={16} aria-hidden={true} />
              <span>MANAGE</span>
            </motion.button>

            <motion.button
              className="utility-button share-button"
              whileTap={{ scale: 0.9 }}
              onClick={handleShare}
              aria-label="Share Rohith's portfolio"
            >
              <Share2 size={17} aria-hidden={true} />
            </motion.button>
          </div>
        </header>

        <div className="orbit-lines" aria-hidden="true">
          <div className="orbit-ring orbit-ring-outer" />
          <div className="orbit-ring orbit-ring-main">
            <motion.svg
              className="wheel-index-ring"
              viewBox="0 0 400 400"
              preserveAspectRatio="none"
              style={{ rotate: ringRotation }}
            >
              <circle
                cx="200"
                cy="200"
                r="194"
                fill="none"
                stroke="currentColor"
                strokeWidth=".6"
                strokeDasharray="1 14"
              />
              <circle
                cx="200"
                cy="200"
                r="198"
                pathLength="100"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeDasharray="7 93"
              />
            </motion.svg>
          </div>
          <div className="orbit-ring orbit-ring-inner" />
          <span className="orbit-tick tick-one" />
          <span className="orbit-tick tick-two" />
        </div>

        <section className="player-identity" aria-label="Rohith Identity">
          <motion.div
            className="identity-content"
            initial={{ opacity: instant ? 1 : 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: instant ? 0 : 0.9 }}
          >
            <span className="identity-eyebrow">
              {prof?.eyebrow ?? "PORTFOLIO · 2026"}
            </span>
            <h1>
              {prof?.fullName ?? "Rohith"}
              <span className="name-period">.</span>
            </h1>
            <p>
              {headlineParts.map((part, idx) => (
                <React.Fragment key={idx}>
                  {idx > 0 && <span> / </span>}
                  {part.trim()}
                </React.Fragment>
              ))}
            </p>
            <div className="identity-rule">
              <span />
              <span>{prof?.identityRuleLabel ?? "ROHITH PORTFOLIO"}</span>
            </div>
          </motion.div>
        </section>

        <OrbitNav
          active={activeIndex}
          position={position}
          geometry={geometry}
          setGeometry={setGeometry}
          onSelect={(idx) => selectSection(idx)}
          navRefs={navRefs}
          onKeyDown={handleNavKeyDown}
          instant={instant}
        />

        <main>
          <section
            id="main-panel"
            className="main-panel"
            role="tabpanel"
            aria-labelledby={`tab-${currentSection.id}`}
            tabIndex={0}
            onTouchStart={(e) => {
              const target = e.target as HTMLElement;
              if (target.closest("a, button, input, textarea, select")) return;
              touchStart.current = {
                x: e.touches[0].clientX,
                y: e.touches[0].clientY,
              };
            }}
            onTouchEnd={(e) => {
              if (!touchStart.current) return;
              const dx = e.changedTouches[0].clientX - touchStart.current.x;
              const dy = e.changedTouches[0].clientY - touchStart.current.y;
              if (Math.abs(dx) > 65 && Math.abs(dx) > Math.abs(dy) * 1.5) {
                selectSection(activeIndex + (dx < 0 ? 1 : -1));
              }
              touchStart.current = null;
            }}
          >
            <div className="panel-meta">
              <span>SELECT YOUR DESTINATION</span>
              <span className="panel-count">
                0{activeIndex + 1}
                <span> / 0{SECTIONS.length}</span>
              </span>
            </div>

            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                className="panel-stage"
                key={currentSection.id}
                initial={{
                  opacity: 0,
                  x: instant ? 0 : direction * 55,
                  y: instant ? 0 : 12,
                  scale: instant ? 1 : 0.96,
                  rotateY: instant ? 0 : direction * 7,
                }}
                animate={{
                  opacity: 1,
                  x: 0,
                  y: 0,
                  scale: 1,
                  rotateY: 0,
                }}
                exit={{
                  opacity: 0,
                  x: instant ? 0 : direction * -35,
                  scale: instant ? 1 : 0.975,
                  rotateY: instant ? 0 : direction * -4,
                  transition: { duration: instant ? 0 : 0.2 },
                }}
                transition={{
                  duration: instant ? 0 : 0.48,
                  ease: [0.16, 1, 0.3, 1],
                }}
              >
                <div className="panel-heading">
                  <h2>
                    {currentSection.id === "home"
                      ? prof?.homeTitle ?? currentSection.title
                      : currentSection.id === "about"
                        ? prof?.aboutTitle ?? currentSection.title
                        : currentSection.title}
                    <span>.</span>
                  </h2>
                  <p>
                    {currentSection.id === "home"
                      ? prof?.homeSubtitle ?? currentSection.subtitle
                      : currentSection.id === "about"
                        ? prof?.aboutSubtitle ?? currentSection.subtitle
                        : currentSection.subtitle}
                  </p>
                </div>

                {/* 01: HOME */}
                {currentSection.id === "home" && (
                  <div className="links-content">
                    <motion.button
                      type="button"
                      className="destination destination-featured destination-highlight"
                      onClick={() => selectSection(3)}
                      whileHover={{ y: -3 }}
                      whileTap={{ scale: 0.975 }}
                      transition={SPRING_TRANSITION}
                    >
                      <span className="highlight-image">
                        <img
                          src="/images/project-featured.png"
                          alt="Rohith portfolio highlight"
                          width={960}
                          height={540}
                          decoding="async"
                        />
                      </span>
                      <span className="destination-text">
                        <span className="highlight-label">
                          <Sparkles size={13} aria-hidden={true} />
                          FEATURED OVERVIEW · ROHITH
                        </span>
                        <span className="destination-title">
                          {prof?.homeHighlightTitle ??
                            "Crafting resilient web applications and refined digital experiences"}
                        </span>
                        <span className="destination-description">
                          {prof?.homeHighlightDescription ??
                            "Navigate through my profile, engineering stack, shipped software projects, and recognitions."}
                        </span>
                        <span className="highlight-action">
                          Explore projects
                          <ArrowUpRight size={16} aria-hidden={true} />
                        </span>
                      </span>
                    </motion.button>

                    <motion.section
                      className="link-group"
                      initial={{
                        opacity: instant ? 1 : 0,
                        x: instant ? 0 : 30,
                        y: instant ? 0 : 8,
                      }}
                      animate={{ opacity: 1, x: 0, y: 0 }}
                      transition={
                        instant
                          ? { duration: 0 }
                          : { ...SPRING_TRANSITION, stiffness: 210, delay: 0.06 }
                      }
                    >
                      <h3>Portfolio sections</h3>
                      <div className="group-links">
                        {SECTIONS.slice(1).map((sec) => {
                          const SecIcon = sec.icon;
                          const targetIdx = SECTIONS.findIndex(
                            (s) => s.id === sec.id
                          );
                          return (
                            <motion.button
                              key={sec.id}
                              type="button"
                              className="destination"
                              onClick={() => selectSection(targetIdx)}
                              whileHover={{ x: 5 }}
                              whileTap={{ scale: 0.975 }}
                              transition={SPRING_TRANSITION}
                            >
                              <span className="destination-icon">
                                <SecIcon
                                  size={22}
                                  strokeWidth={1.35}
                                  aria-hidden={true}
                                />
                              </span>
                              <span className="destination-text">
                                <span className="destination-title">
                                  {sec.label}
                                </span>
                                <span className="destination-description">
                                  {sec.subtitle}
                                </span>
                              </span>
                              <ArrowUpRight
                                className="external-icon"
                                size={17}
                                strokeWidth={1.3}
                                aria-hidden={true}
                              />
                            </motion.button>
                          );
                        })}
                      </div>
                    </motion.section>
                  </div>
                )}

                {/* 02: ABOUT ME */}
                {currentSection.id === "about" && (
                  <div className="about-content">
                    <div className="profile-card">
                      <img
                        src={prof?.avatarUrl || "/images/rohith-avatar.png"}
                        alt="Rohith"
                        width={80}
                        height={80}
                      />
                      <div>
                        <span className="small-label">
                          {prof?.aboutLabel ?? "THE DEVELOPER"}
                        </span>
                        <h3>{prof?.aboutGreeting ?? "Hey, I’m Rohith."}</h3>
                        <p>
                          {prof?.aboutRoleLine ??
                            "Full-Stack Developer · UI Architect · Problem Solver"}
                        </p>
                      </div>
                    </div>

                    <p className="about-intro">
                      {prof?.aboutIntroLead ?? "Designing and engineering "}
                      <em>
                        {prof?.aboutIntroAccent ??
                          "scalable systems, clear interfaces, and purposeful software."}
                      </em>
                    </p>

                    <p className="about-copy">
                      {prof?.aboutCopy ??
                        "I build end-to-end web platforms with strong architectural discipline—bridging responsive frontend craft with dependable PostgreSQL and TypeScript backends."}
                    </p>

                    <div className="creative-roles">
                      {(
                        prof?.focusAreas ?? [
                          "Full-stack web systems",
                          "Frontend architecture",
                          "API & database design",
                        ]
                      ).map((area) => (
                        <span key={area}>{area}</span>
                      ))}
                    </div>

                    <div className="group-links">
                      <motion.button
                        type="button"
                        className="destination"
                        onClick={() => selectSection(2)}
                        whileHover={{ x: 5 }}
                        whileTap={{ scale: 0.975 }}
                        transition={SPRING_TRANSITION}
                      >
                        <span className="destination-icon">
                          <MapPin
                            size={22}
                            strokeWidth={1.35}
                            aria-hidden={true}
                          />
                        </span>
                        <span className="destination-text">
                          <span className="destination-title">
                            {prof?.location ?? "Bengaluru, India"}
                          </span>
                          <span className="destination-description">
                            {prof?.availability ??
                              "Available for software engineering & product collaborations"}
                          </span>
                        </span>
                        <ArrowUpRight
                          className="external-icon"
                          size={17}
                          strokeWidth={1.3}
                          aria-hidden={true}
                        />
                      </motion.button>

                      <motion.button
                        type="button"
                        className="destination destination-featured"
                        onClick={() => selectSection(3)}
                        whileHover={{ x: 5 }}
                        whileTap={{ scale: 0.975 }}
                        transition={SPRING_TRANSITION}
                      >
                        <span className="destination-icon">
                          <FolderGit2
                            size={22}
                            strokeWidth={1.35}
                            aria-hidden={true}
                          />
                        </span>
                        <span className="destination-text">
                          <span className="destination-title">
                            Browse Rohith&apos;s Projects
                          </span>
                          <span className="destination-description">
                            {data.projects.length} engineered builds stored in
                            the portfolio database
                          </span>
                        </span>
                        <ArrowUpRight
                          className="external-icon"
                          size={17}
                          strokeWidth={1.3}
                          aria-hidden={true}
                        />
                      </motion.button>
                    </div>
                  </div>
                )}

                {/* 03: SKILLS */}
                {currentSection.id === "skills" && (
                  <div className="skills-content">
                    {Object.entries(skillsByCategory).map(
                      ([category, items], groupIdx) => (
                        <motion.section
                          key={category}
                          className="link-group"
                          initial={{
                            opacity: instant ? 1 : 0,
                            x: instant ? 0 : 30,
                            y: instant ? 0 : 8,
                          }}
                          animate={{ opacity: 1, x: 0, y: 0 }}
                          transition={
                            instant
                              ? { duration: 0 }
                              : {
                                  ...SPRING_TRANSITION,
                                  stiffness: 210,
                                  delay: groupIdx * 0.08,
                                }
                          }
                        >
                          <h3>{category}</h3>
                          <div className="group-links">
                            {items.map((skill) => (
                              <motion.div
                                key={skill.id}
                                className="destination"
                                whileHover={{ x: 5 }}
                                transition={SPRING_TRANSITION}
                              >
                                <span className="destination-icon">
                                  <Layers
                                    size={21}
                                    strokeWidth={1.35}
                                    aria-hidden={true}
                                  />
                                </span>
                                <span className="destination-text">
                                  <span className="destination-title">
                                    {skill.name}
                                  </span>
                                  <span className="destination-description">
                                    {skill.description}
                                  </span>
                                </span>
                                <span className="pill-badge">
                                  {skill.proficiency}
                                </span>
                              </motion.div>
                            ))}
                          </div>
                        </motion.section>
                      )
                    )}
                  </div>
                )}

                {/* 04: PROJECTS */}
                {currentSection.id === "projects" && (
                  <div className="projects-content">
                    {featuredProject && (
                      <motion.button
                        type="button"
                        className="destination destination-featured destination-highlight"
                        onClick={() => setSelectedProject(featuredProject)}
                        whileHover={{ y: -3 }}
                        whileTap={{ scale: 0.975 }}
                        transition={SPRING_TRANSITION}
                      >
                        <span className="highlight-image">
                          <img
                            src={
                              featuredProject.thumbnailUrl ||
                              "/images/project-featured.png"
                            }
                            alt={featuredProject.title}
                            width={960}
                            height={540}
                            decoding="async"
                          />
                        </span>
                        <span className="destination-text">
                          <span className="highlight-label">
                            <FolderGit2 size={13} aria-hidden={true} />
                            {featuredProject.category.toUpperCase()} ·{" "}
                            {featuredProject.year}
                          </span>
                          <span className="destination-title">
                            {featuredProject.title}
                          </span>
                          <span className="destination-description">
                            {featuredProject.summary}
                          </span>
                          <span className="tech-tags">
                            {(featuredProject.techStack ?? []).map((tech) => (
                              <span key={tech} className="tech-tag">
                                {tech}
                              </span>
                            ))}
                          </span>
                          <span className="highlight-action">
                            Inspect project details
                            <ArrowUpRight size={16} aria-hidden={true} />
                          </span>
                        </span>
                      </motion.button>
                    )}

                    {secondaryProjects.length > 0 && (
                      <motion.section
                        className="link-group"
                        initial={{
                          opacity: instant ? 1 : 0,
                          x: instant ? 0 : 30,
                          y: instant ? 0 : 8,
                        }}
                        animate={{ opacity: 1, x: 0, y: 0 }}
                        transition={
                          instant
                            ? { duration: 0 }
                            : {
                                ...SPRING_TRANSITION,
                                stiffness: 210,
                                delay: 0.08,
                              }
                        }
                      >
                        <h3>Engineered builds</h3>
                        <div className="group-links">
                          {secondaryProjects.map((project) => (
                            <motion.button
                              key={project.id}
                              type="button"
                              className="destination"
                              onClick={() => setSelectedProject(project)}
                              whileHover={{ x: 5 }}
                              whileTap={{ scale: 0.975 }}
                              transition={SPRING_TRANSITION}
                            >
                              <span className="destination-icon">
                                <FolderGit2
                                  size={22}
                                  strokeWidth={1.35}
                                  aria-hidden={true}
                                />
                              </span>
                              <span className="destination-text">
                                <span className="destination-title">
                                  {project.title}
                                </span>
                                <span className="destination-description">
                                  {project.summary}
                                </span>
                                <span className="tech-tags">
                                  {(project.techStack ?? []).map((tech) => (
                                    <span key={tech} className="tech-tag">
                                      {tech}
                                    </span>
                                  ))}
                                </span>
                              </span>
                              <ArrowUpRight
                                className="external-icon"
                                size={17}
                                strokeWidth={1.3}
                                aria-hidden={true}
                              />
                            </motion.button>
                          ))}
                        </div>
                      </motion.section>
                    )}
                  </div>
                )}

                {/* 05: ACHIEVEMENTS */}
                {currentSection.id === "achievements" && (
                  <div className="achievements-content">
                    <motion.section
                      className="link-group"
                      initial={{
                        opacity: instant ? 1 : 0,
                        x: instant ? 0 : 30,
                        y: instant ? 0 : 8,
                      }}
                      animate={{ opacity: 1, x: 0, y: 0 }}
                      transition={
                        instant
                          ? { duration: 0 }
                          : { ...SPRING_TRANSITION, stiffness: 210 }
                      }
                    >
                      <h3>Honors &amp; certifications</h3>
                      <div className="group-links">
                        {data.achievements.map((item) => (
                          <motion.div
                            key={item.id}
                            className="destination"
                            whileHover={{ x: 5 }}
                            transition={SPRING_TRANSITION}
                          >
                            <span className="destination-icon">
                              <Award
                                size={22}
                                strokeWidth={1.35}
                                aria-hidden={true}
                              />
                            </span>
                            <span className="destination-text">
                              <span className="destination-title">
                                {item.title}
                              </span>
                              <span className="destination-description">
                                {item.description}
                              </span>
                              <span className="tech-tags">
                                <span className="tech-tag">{item.issuer}</span>
                                <span className="tech-tag">{item.year}</span>
                                <span className="tech-tag">
                                  {item.category}
                                </span>
                              </span>
                            </span>
                          </motion.div>
                        ))}
                      </div>
                    </motion.section>
                  </div>
                )}

                {/* 06: CONTACT */}
                {currentSection.id === "contact" && (
                  <div className="contact-content">
                    <form
                      className="contact-form"
                      onSubmit={handleContactSubmit}
                    >
                      <div className="contact-form-row">
                        <div className="field-group">
                          <label className="field-label" htmlFor="sender-name">
                            Your name
                          </label>
                          <input
                            id="sender-name"
                            className="gold-input"
                            type="text"
                            required
                            placeholder="Enter your name"
                            value={senderName}
                            onChange={(e) => setSenderName(e.target.value)}
                          />
                        </div>
                        <div className="field-group">
                          <label className="field-label" htmlFor="sender-email">
                            Email address
                          </label>
                          <input
                            id="sender-email"
                            className="gold-input"
                            type="email"
                            required
                            placeholder="you@example.com"
                            value={senderEmail}
                            onChange={(e) => setSenderEmail(e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="field-group">
                        <label className="field-label" htmlFor="contact-subject">
                          Subject
                        </label>
                        <input
                          id="contact-subject"
                          className="gold-input"
                          type="text"
                          placeholder="Collaboration, role, or engineering inquiry"
                          value={subject}
                          onChange={(e) => setSubject(e.target.value)}
                        />
                      </div>

                      <div className="field-group">
                        <label className="field-label" htmlFor="contact-message">
                          Message
                        </label>
                        <textarea
                          id="contact-message"
                          className="gold-textarea"
                          required
                          placeholder="Share context, timeline, or how Rohith can help..."
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                        />
                      </div>

                      <motion.button
                        type="submit"
                        className="primary-action"
                        disabled={submittingContact}
                        whileTap={{ scale: 0.985 }}
                      >
                        <Send size={16} aria-hidden={true} />
                        <span>
                          {submittingContact ? "SENDING..." : "SEND MESSAGE"}
                        </span>
                      </motion.button>
                    </form>

                    <section className="contact-notes">
                      <h3>Before you send a note</h3>
                      {[
                        "Include a brief overview of your project, role, or collaboration idea.",
                        "Messages are saved directly to Rohith's PostgreSQL portfolio inbox.",
                        "Expect a thoughtful reply within 24–48 hours.",
                      ].map((note) => (
                        <p key={note}>
                          <Check size={15} aria-hidden={true} />
                          <span>{note}</span>
                        </p>
                      ))}
                      <p className="no-spam">
                        Please keep inquiries relevant and respectful.
                      </p>
                    </section>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            <div className="panel-navigation">
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => selectSection(activeIndex - 1)}
                aria-label="Previous section"
              >
                <ChevronLeft size={16} aria-hidden={true} />
              </motion.button>
              <span className="swipe-hint">SWIPE TO CHANGE SECTIONS</span>
              <span className="desktop-hint">USE ARROW KEYS TO NAVIGATE</span>
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => selectSection(activeIndex + 1)}
                aria-label="Next section"
              >
                <ChevronRight size={16} aria-hidden={true} />
              </motion.button>
            </div>
          </section>
        </main>

        <footer className="bottom-bar">
          <span>&copy; {new Date().getFullYear()} ROHITH</span>
          <span className="footer-center">CRAFTED WITH PRECISION.</span>
          <span>
            ROHITH <span className="footer-gold">PORTFOLIO</span>
          </span>
        </footer>

        {/* Project Detail Modal */}
        <AnimatePresence>
          {selectedProject && (
            <motion.div
              className="modal-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProject(null)}
            >
              <motion.div
                className="modal-card"
                initial={{ opacity: 0, y: 16, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 12, scale: 0.98 }}
                onClick={(e) => e.stopPropagation()}
              >
                <div className="modal-header">
                  <div>
                    <span className="small-label">
                      {selectedProject.category.toUpperCase()} ·{" "}
                      {selectedProject.year}
                    </span>
                    <h3>
                      {selectedProject.title}
                      <span className="name-period">.</span>
                    </h3>
                  </div>
                  <button
                    type="button"
                    className="utility-button"
                    onClick={() => setSelectedProject(null)}
                    aria-label="Close project details"
                  >
                    <X size={18} />
                  </button>
                </div>

                <p className="about-copy" style={{ marginTop: 0 }}>
                  {selectedProject.details || selectedProject.summary}
                </p>

                <div className="tech-tags" style={{ margin: "16px 0 20px" }}>
                  {(selectedProject.techStack ?? []).map((tech) => (
                    <span key={tech} className="tech-tag">
                      {tech}
                    </span>
                  ))}
                </div>

                <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>
                  <button
                    type="button"
                    className="primary-action"
                    style={{ margin: 0, flex: 1 }}
                    onClick={() => {
                      setSelectedProject(null);
                      selectSection(5);
                    }}
                  >
                    <ExternalLink size={15} />
                    <span>INQUIRE ABOUT THIS BUILD</span>
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Portfolio Backend Studio Modal (PostgreSQL CRUD) */}
        <AnimatePresence>
          {studioOpen && (
            <motion.div
              className="modal-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setStudioOpen(false)}
            >
              <motion.div
                className="modal-card"
                initial={{ opacity: 0, y: 16, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 12, scale: 0.98 }}
                onClick={(e) => e.stopPropagation()}
              >
                <div className="modal-header">
                  <div>
                    <span className="small-label">POSTGRESQL BACKEND</span>
                    <h3>
                      Manage Portfolio<span className="name-period">.</span>
                    </h3>
                  </div>
                  <button
                    type="button"
                    className="utility-button"
                    onClick={() => setStudioOpen(false)}
                    aria-label="Close backend manager"
                  >
                    <X size={18} />
                  </button>
                </div>

                <div className="studio-tabs">
                  {(
                    [
                      ["about", "ABOUT ME"],
                      ["skills", "SKILLS"],
                      ["projects", "PROJECTS"],
                      ["achievements", "ACHIEVEMENTS"],
                      ["messages", `INBOX (${data.messages.length})`],
                    ] as const
                  ).map(([tabKey, tabLabel]) => (
                    <button
                      key={tabKey}
                      type="button"
                      className={`studio-tab ${studioTab === tabKey ? "is-active" : ""}`}
                      onClick={() => setStudioTab(tabKey)}
                    >
                      {tabLabel}
                    </button>
                  ))}
                </div>

                {studioTab === "about" && (
                  <form className="contact-form" onSubmit={handleSaveAbout}>
                    <div className="field-group">
                      <label className="field-label">Role Headline</label>
                      <input
                        className="gold-input"
                        value={aboutForm.headline}
                        onChange={(e) =>
                          setAboutForm({
                            ...aboutForm,
                            headline: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div className="contact-form-row">
                      <div className="field-group">
                        <label className="field-label">Greeting</label>
                        <input
                          className="gold-input"
                          value={aboutForm.aboutGreeting}
                          onChange={(e) =>
                            setAboutForm({
                              ...aboutForm,
                              aboutGreeting: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div className="field-group">
                        <label className="field-label">Location</label>
                        <input
                          className="gold-input"
                          value={aboutForm.location}
                          onChange={(e) =>
                            setAboutForm({
                              ...aboutForm,
                              location: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>
                    <div className="field-group">
                      <label className="field-label">Intro Highlight</label>
                      <input
                        className="gold-input"
                        value={aboutForm.aboutIntroAccent}
                        onChange={(e) =>
                          setAboutForm({
                            ...aboutForm,
                            aboutIntroAccent: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div className="field-group">
                      <label className="field-label">Bio Copy</label>
                      <textarea
                        className="gold-textarea"
                        value={aboutForm.aboutCopy}
                        onChange={(e) =>
                          setAboutForm({
                            ...aboutForm,
                            aboutCopy: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div className="field-group">
                      <label className="field-label">
                        Focus Areas (comma separated)
                      </label>
                      <input
                        className="gold-input"
                        value={aboutForm.focusAreas}
                        onChange={(e) =>
                          setAboutForm({
                            ...aboutForm,
                            focusAreas: e.target.value,
                          })
                        }
                      />
                    </div>
                    <button
                      type="submit"
                      className="primary-action"
                      disabled={busyAction}
                    >
                      SAVE PROFILE CHANGES
                    </button>
                  </form>
                )}

                {studioTab === "skills" && (
                  <div>
                    <form className="contact-form" onSubmit={handleAddSkill}>
                      <div className="contact-form-row">
                        <div className="field-group">
                          <label className="field-label">Skill Name</label>
                          <input
                            className="gold-input"
                            required
                            placeholder="e.g. GraphQL & Prisma"
                            value={skillForm.name}
                            onChange={(e) =>
                              setSkillForm({
                                ...skillForm,
                                name: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="field-group">
                          <label className="field-label">Category</label>
                          <input
                            className="gold-input"
                            value={skillForm.category}
                            onChange={(e) =>
                              setSkillForm({
                                ...skillForm,
                                category: e.target.value,
                              })
                            }
                          />
                        </div>
                      </div>
                      <div className="contact-form-row">
                        <div className="field-group">
                          <label className="field-label">Description</label>
                          <input
                            className="gold-input"
                            required
                            placeholder="Brief capability summary"
                            value={skillForm.description}
                            onChange={(e) =>
                              setSkillForm({
                                ...skillForm,
                                description: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="field-group">
                          <label className="field-label">Proficiency</label>
                          <input
                            className="gold-input"
                            value={skillForm.proficiency}
                            onChange={(e) =>
                              setSkillForm({
                                ...skillForm,
                                proficiency: e.target.value,
                              })
                            }
                          />
                        </div>
                      </div>
                      <button
                        type="submit"
                        className="primary-action"
                        disabled={busyAction}
                      >
                        <Plus size={15} />
                        <span>ADD SKILL</span>
                      </button>
                    </form>

                    <div>
                      {data.skills.map((s) => (
                        <div key={s.id} className="studio-list-item">
                          <div>
                            <div className="destination-title">{s.name}</div>
                            <div className="destination-description">
                              {s.category} · {s.proficiency}
                            </div>
                          </div>
                          <button
                            type="button"
                            className="utility-button"
                            onClick={() => handleDeleteSkill(s.id)}
                            aria-label={`Delete ${s.name}`}
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {studioTab === "projects" && (
                  <div>
                    <form className="contact-form" onSubmit={handleAddProject}>
                      <div className="contact-form-row">
                        <div className="field-group">
                          <label className="field-label">Project Title</label>
                          <input
                            className="gold-input"
                            required
                            placeholder="e.g. Nimbus Cloud Console"
                            value={projectForm.title}
                            onChange={(e) =>
                              setProjectForm({
                                ...projectForm,
                                title: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="field-group">
                          <label className="field-label">Category</label>
                          <input
                            className="gold-input"
                            value={projectForm.category}
                            onChange={(e) =>
                              setProjectForm({
                                ...projectForm,
                                category: e.target.value,
                              })
                            }
                          />
                        </div>
                      </div>
                      <div className="field-group">
                        <label className="field-label">Summary</label>
                        <input
                          className="gold-input"
                          required
                          placeholder="Short description of the project"
                          value={projectForm.summary}
                          onChange={(e) =>
                            setProjectForm({
                              ...projectForm,
                              summary: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div className="field-group">
                        <label className="field-label">
                          Tech Stack (comma separated)
                        </label>
                        <input
                          className="gold-input"
                          value={projectForm.techStack}
                          onChange={(e) =>
                            setProjectForm({
                              ...projectForm,
                              techStack: e.target.value,
                            })
                          }
                        />
                      </div>
                      <button
                        type="submit"
                        className="primary-action"
                        disabled={busyAction}
                      >
                        <Plus size={15} />
                        <span>ADD PROJECT</span>
                      </button>
                    </form>

                    <div>
                      {data.projects.map((p) => (
                        <div key={p.id} className="studio-list-item">
                          <div>
                            <div className="destination-title">{p.title}</div>
                            <div className="destination-description">
                              {p.category} · {p.year}
                            </div>
                          </div>
                          <button
                            type="button"
                            className="utility-button"
                            onClick={() => handleDeleteProject(p.id)}
                            aria-label={`Delete ${p.title}`}
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {studioTab === "achievements" && (
                  <div>
                    <form
                      className="contact-form"
                      onSubmit={handleAddAchievement}
                    >
                      <div className="contact-form-row">
                        <div className="field-group">
                          <label className="field-label">
                            Achievement Title
                          </label>
                          <input
                            className="gold-input"
                            required
                            placeholder="e.g. Cloud Engineering Fellowship"
                            value={achievementForm.title}
                            onChange={(e) =>
                              setAchievementForm({
                                ...achievementForm,
                                title: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="field-group">
                          <label className="field-label">Issuer</label>
                          <input
                            className="gold-input"
                            required
                            placeholder="e.g. Engineering Council"
                            value={achievementForm.issuer}
                            onChange={(e) =>
                              setAchievementForm({
                                ...achievementForm,
                                issuer: e.target.value,
                              })
                            }
                          />
                        </div>
                      </div>
                      <div className="field-group">
                        <label className="field-label">Description</label>
                        <input
                          className="gold-input"
                          required
                          placeholder="Details about this recognition"
                          value={achievementForm.description}
                          onChange={(e) =>
                            setAchievementForm({
                              ...achievementForm,
                              description: e.target.value,
                            })
                          }
                        />
                      </div>
                      <button
                        type="submit"
                        className="primary-action"
                        disabled={busyAction}
                      >
                        <Plus size={15} />
                        <span>ADD ACHIEVEMENT</span>
                      </button>
                    </form>

                    <div>
                      {data.achievements.map((a) => (
                        <div key={a.id} className="studio-list-item">
                          <div>
                            <div className="destination-title">{a.title}</div>
                            <div className="destination-description">
                              {a.issuer} · {a.year}
                            </div>
                          </div>
                          <button
                            type="button"
                            className="utility-button"
                            onClick={() => handleDeleteAchievement(a.id)}
                            aria-label={`Delete ${a.title}`}
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {studioTab === "messages" && (
                  <div>
                    {data.messages.length === 0 ? (
                      <p className="panel-note">
                        No contact messages received yet.
                      </p>
                    ) : (
                      data.messages.map((msg) => (
                        <div
                          key={msg.id}
                          className="studio-list-item"
                          style={{ alignItems: "flex-start" }}
                        >
                          <div>
                            <div className="destination-title">
                              {msg.subject} — {msg.senderName}
                            </div>
                            <div
                              className="small-label"
                              style={{ margin: "3px 0" }}
                            >
                              {msg.senderEmail}
                            </div>
                            <div className="destination-description">
                              {msg.message}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="notice-region" role="status" aria-live="polite">
          <AnimatePresence>
            {toastMessage && (
              <motion.div
                className="toast"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 6 }}
              >
                <Check size={16} aria-hidden={true} />
                <span>{toastMessage}</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </MotionConfig>
  );
}
