import { NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select()
      .from(contactMessages)
      .orderBy(desc(contactMessages.createdAt), desc(contactMessages.id))
      .limit(25);
    return NextResponse.json({ messages: rows });
  } catch (error) {
    console.error("Failed to fetch contact messages:", error);
    return NextResponse.json(
      { error: "Failed to load contact messages" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const senderName = String(body.senderName ?? "").trim();
    const senderEmail = String(body.senderEmail ?? "").trim();
    const subject = String(body.subject ?? "Portfolio Inquiry").trim();
    const message = String(body.message ?? "").trim();

    if (!senderName || !senderEmail || !message) {
      return NextResponse.json(
        { error: "Name, email, and message are required." },
        { status: 400 }
      );
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(senderEmail)) {
      return NextResponse.json(
        { error: "Please enter a valid email address." },
        { status: 400 }
      );
    }

    const [created] = await db
      .insert(contactMessages)
      .values({
        senderName,
        senderEmail,
        subject: subject || "Portfolio Inquiry",
        message,
        status: "new",
      })
      .returning();

    return NextResponse.json({ message: created }, { status: 201 });
  } catch (error) {
    console.error("Failed to save contact message:", error);
    return NextResponse.json(
      { error: "Failed to send message" },
      { status: 500 }
    );
  }
}
