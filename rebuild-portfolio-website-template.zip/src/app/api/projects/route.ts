import { NextResponse } from "next/server";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { asc, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();
    const rows = await db
      .select()
      .from(projects)
      .orderBy(desc(projects.featured), asc(projects.sortOrder), asc(projects.id));
    return NextResponse.json({ projects: rows });
  } catch (error) {
    console.error("Failed to fetch projects:", error);
    return NextResponse.json({ error: "Failed to fetch projects" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const title = String(body.title ?? "").trim();
    const summary = String(body.summary ?? "").trim();
    const details = String(body.details ?? summary).trim();
    const category = String(body.category ?? "Web Application").trim();
    const year = String(body.year ?? new Date().getFullYear()).trim();
    const featured = Boolean(body.featured);
    const liveUrl = String(body.liveUrl ?? "").trim();
    const repoUrl = String(body.repoUrl ?? "").trim();
    const techStack = Array.isArray(body.techStack)
      ? body.techStack.map((t: unknown) => String(t).trim()).filter(Boolean)
      : typeof body.techStack === "string"
        ? body.techStack
            .split(",")
            .map((t: string) => t.trim())
            .filter(Boolean)
        : ["Next.js", "TypeScript"];

    if (!title || !summary) {
      return NextResponse.json(
        { error: "Project title and summary are required." },
        { status: 400 }
      );
    }

    const [created] = await db
      .insert(projects)
      .values({
        title,
        summary,
        details,
        techStack,
        category,
        year,
        featured,
        thumbnailUrl: featured ? "/images/project-featured.png" : "",
        liveUrl,
        repoUrl,
        sortOrder: Number(body.sortOrder ?? 99),
      })
      .returning();

    return NextResponse.json({ project: created }, { status: 201 });
  } catch (error) {
    console.error("Failed to create project:", error);
    return NextResponse.json({ error: "Failed to create project" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = Number(searchParams.get("id"));
    if (!Number.isInteger(id) || id <= 0) {
      return NextResponse.json(
        { error: "Valid project id is required." },
        { status: 400 }
      );
    }
    await db.delete(projects).where(eq(projects.id, id));
    return NextResponse.json({ deleted: true, id });
  } catch (error) {
    console.error("Failed to delete project:", error);
    return NextResponse.json({ error: "Failed to delete project" }, { status: 500 });
  }
}
