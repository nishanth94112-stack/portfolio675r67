import { NextResponse } from "next/server";
import { db } from "@/db";
import { achievements } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();
    const rows = await db
      .select()
      .from(achievements)
      .orderBy(asc(achievements.sortOrder), asc(achievements.id));
    return NextResponse.json({ achievements: rows });
  } catch (error) {
    console.error("Failed to fetch achievements:", error);
    return NextResponse.json(
      { error: "Failed to fetch achievements" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const title = String(body.title ?? "").trim();
    const issuer = String(body.issuer ?? "").trim();
    const year = String(body.year ?? new Date().getFullYear()).trim();
    const category = String(body.category ?? "Recognition").trim();
    const description = String(body.description ?? "").trim();

    if (!title || !issuer || !description) {
      return NextResponse.json(
        { error: "Title, issuer, and description are required." },
        { status: 400 }
      );
    }

    const [created] = await db
      .insert(achievements)
      .values({
        title,
        issuer,
        year,
        category,
        description,
        sortOrder: Number(body.sortOrder ?? 99),
      })
      .returning();

    return NextResponse.json({ achievement: created }, { status: 201 });
  } catch (error) {
    console.error("Failed to create achievement:", error);
    return NextResponse.json(
      { error: "Failed to create achievement" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = Number(searchParams.get("id"));
    if (!Number.isInteger(id) || id <= 0) {
      return NextResponse.json(
        { error: "Valid achievement id is required." },
        { status: 400 }
      );
    }
    await db.delete(achievements).where(eq(achievements.id, id));
    return NextResponse.json({ deleted: true, id });
  } catch (error) {
    console.error("Failed to delete achievement:", error);
    return NextResponse.json(
      { error: "Failed to delete achievement" },
      { status: 500 }
    );
  }
}
