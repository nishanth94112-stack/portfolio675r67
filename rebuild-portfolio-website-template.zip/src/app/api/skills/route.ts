import { NextResponse } from "next/server";
import { db } from "@/db";
import { skills } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();
    const rows = await db
      .select()
      .from(skills)
      .orderBy(asc(skills.sortOrder), asc(skills.id));
    return NextResponse.json({ skills: rows });
  } catch (error) {
    console.error("Failed to fetch skills:", error);
    return NextResponse.json({ error: "Failed to fetch skills" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const name = String(body.name ?? "").trim();
    const category = String(body.category ?? "Core Technologies").trim();
    const description = String(body.description ?? "").trim();
    const proficiency = String(body.proficiency ?? "Advanced").trim();

    if (!name || !description) {
      return NextResponse.json(
        { error: "Skill name and description are required." },
        { status: 400 }
      );
    }

    const [created] = await db
      .insert(skills)
      .values({
        name,
        category,
        description,
        proficiency,
        sortOrder: Number(body.sortOrder ?? 99),
      })
      .returning();

    return NextResponse.json({ skill: created }, { status: 201 });
  } catch (error) {
    console.error("Failed to create skill:", error);
    return NextResponse.json({ error: "Failed to create skill" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = Number(searchParams.get("id"));
    if (!Number.isInteger(id) || id <= 0) {
      return NextResponse.json({ error: "Valid skill id is required." }, { status: 400 });
    }
    await db.delete(skills).where(eq(skills.id, id));
    return NextResponse.json({ deleted: true, id });
  } catch (error) {
    console.error("Failed to delete skill:", error);
    return NextResponse.json({ error: "Failed to delete skill" }, { status: 500 });
  }
}
