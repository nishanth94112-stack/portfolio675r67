import { NextResponse } from "next/server";
import { db } from "@/db";
import { profile } from "@/db/schema";
import { getPortfolioData, ensureSeeded } from "@/db/seed";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const data = await getPortfolioData();
    return NextResponse.json(data);
  } catch (error) {
    console.error("Failed to fetch portfolio data:", error);
    return NextResponse.json(
      { error: "Failed to load portfolio data" },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const existing = await db.select().from(profile).limit(1);

    if (!existing[0]) {
      return NextResponse.json({ error: "Profile not found" }, { status: 404 });
    }

    const focusAreas = Array.isArray(body.focusAreas)
      ? body.focusAreas.map((item: unknown) => String(item).trim()).filter(Boolean)
      : existing[0].focusAreas;

    const [updated] = await db
      .update(profile)
      .set({
        headline:
          typeof body.headline === "string" && body.headline.trim()
            ? body.headline.trim()
            : existing[0].headline,
        aboutGreeting:
          typeof body.aboutGreeting === "string" && body.aboutGreeting.trim()
            ? body.aboutGreeting.trim()
            : existing[0].aboutGreeting,
        aboutRoleLine:
          typeof body.aboutRoleLine === "string" && body.aboutRoleLine.trim()
            ? body.aboutRoleLine.trim()
            : existing[0].aboutRoleLine,
        aboutIntroLead:
          typeof body.aboutIntroLead === "string"
            ? body.aboutIntroLead
            : existing[0].aboutIntroLead,
        aboutIntroAccent:
          typeof body.aboutIntroAccent === "string" && body.aboutIntroAccent.trim()
            ? body.aboutIntroAccent.trim()
            : existing[0].aboutIntroAccent,
        aboutCopy:
          typeof body.aboutCopy === "string" && body.aboutCopy.trim()
            ? body.aboutCopy.trim()
            : existing[0].aboutCopy,
        location:
          typeof body.location === "string" && body.location.trim()
            ? body.location.trim()
            : existing[0].location,
        availability:
          typeof body.availability === "string" && body.availability.trim()
            ? body.availability.trim()
            : existing[0].availability,
        focusAreas,
        updatedAt: new Date(),
      })
      .where(eq(profile.id, existing[0].id))
      .returning();

    return NextResponse.json({ profile: updated });
  } catch (error) {
    console.error("Failed to update profile:", error);
    return NextResponse.json(
      { error: "Failed to update profile" },
      { status: 500 }
    );
  }
}
