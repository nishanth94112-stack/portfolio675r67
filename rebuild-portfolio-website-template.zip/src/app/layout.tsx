import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Rohith | Portfolio",
  description:
    "Rohith's personal portfolio showcasing background, skills, projects, achievements, and contact.",
  authors: [{ name: "Rohith" }],
};

export const viewport: Viewport = {
  themeColor: "#080f1d",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <a href="#main-panel" className="skip-link">
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}
