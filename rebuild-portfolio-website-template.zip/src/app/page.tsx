import { getPortfolioData } from "@/db/seed";
import PortfolioShell from "@/components/PortfolioShell";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const initialData = await getPortfolioData();
  return <PortfolioShell initialData={initialData} />;
}
